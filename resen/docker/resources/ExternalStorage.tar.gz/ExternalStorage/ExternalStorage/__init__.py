import os


# Now import the fuse tool wrappers
import gdfs_wrapper

# Add the fuse tool wrappers to the dictionary of known storage systems
_storage_systems = {'google':['Google Drive',gdfs_wrapper]} #,
                  #'dropbox':['Dropbox',ff4d_wrapper]}

available = ["%s: %s" % (_storage_systems[x][0],x) for x in sorted(_storage_systems.keys())]


def print_available():
    for line in available:
        print(line)

# A class that provides a VERY simple way for users to mount cloud storage using FUSE
# Only ever intended to provide authentication, mounting, and unmounting.
class Service(object):

    def __init__(self,credentials_directory,mount_directory,storage='google'):

        # User input checking
        if not isinstance(credentials_directory,str):
            print("ERROR: credentials_directory must be a string!")
            return None
        if not isinstance(mount_directory,str):
            print("ERROR: credentials_directory must be a string!")
            return None
        if not isinstance(storage,str):
            print("ERROR: storage must be a string!")
            return None

        # Ensure credentials_directory exists, else attempt to create it
        if not os.path.exists(credentials_directory):
            try:
                os.mkdir(credentials_directory)
            except OSError:
                print("ERROR: There was a problem creating the credentials directory.")
                return None

        # Ensure mount_directory exists, else attempt to create it
        if not os.path.exists(mount_directory):
            try:
                os.mkdir(mount_directory)
            except OSError:
                print("ERROR: There was a problem creating the mounting directory.")
                return None

        # Check the user specified storage
        if not (storage in _storage_systems.keys()):
            print("ERROR: storage must be one of: %s" % ", ".join(sorted(_storage_systems.keys())))
            return None

        self.mount_directory = os.path.join(mount_directory,storage)
        self.__wrapper = _storage_systems[storage][1]
        credentials_file = storage + ".creds"
        self.credentials_file = os.path.join(credentials_directory,credentials_file)

        print("Initialized %s" % _storage_systems[storage][0])
        print("Use: authenticate(), mount(), and unmount()")


    def authenticate(self):

        status = self.__wrapper.authenticate(self.credentials_file)

        if status:
            pass


    def mount(self):
        # check if mount directory exists, if not, create it
        if not os.path.exists(self.mount_directory):
            try:
                os.mkdir(self.mount_directory)
            except OSError:
                print("ERROR: There was a problem creating %s" % (self.mount_directory))
                return None

        # check if already mounted
        if not os.path.ismount(self.mount_directory):
            print("Mounting...")
            try:
                status = self.__wrapper.mount(self.credentials_file,self.mount_directory)
                if status == 0:
                    print("Success!")
                else:
                    print("Failed. See above.")
            except Exception as e:
                print("Failed to mount: %s" % str(e))

        else:
            print("Already mounted")
        

    def unmount(self):
        # check if mounted or not, unmount if mounted
        if os.path.ismount(self.mount_directory):
            print("Unmounting...")
            try:
                status = self.__wrapper.unmount(self.credentials_file,self.mount_directory)
                if status == 0:
                    print("Success!")
                else:
                    print("Failed. See above. Wait a few seconds and try again.")
            except Exception as e:
                print("Failed to unmount: %s" % str(e))

        else:
            print("Not mounted!")