import os
import gdrivefs.config
import gdrivefs.config.log
import gdrivefs.gdfs.gdfuse
import gdrivefs.gdtool.oauth_authorize
from gdrivefs.errors import AuthorizationFailureError

__gdfstool_location = os.path.abspath(os.path.dirname(__file__))

def check_existance_filepath(filename):
    # Now store the token in the auth file.
    if not os.path.exists(filename):
        filepath = os.path.dirname(filename)

        if os.path.exists(filepath) is False:
            raise EnvironmentError("The path %s for the file %s "
                                   "does not exist:" % 
                                   (filepath, os.path.basename(filename)))


def authenticate(credentials_file):
    # Largerly adapted from gdfstool

    # Ensure the credentials file path exists.
    check_existance_filepath(credentials_file)

    # Check to see if we are already authorized. If not, run authorization.
    gdrivefs.gdfs.gdfuse.set_auth_cache_filepath(credentials_file)
    authorize = gdrivefs.gdtool.oauth_authorize.get_auth()

    #authorize.cache_filepath = credentials_file
    print credentials_file

    try:
        authorize.get_credentials()
        authorize.check_credential_state()
        print("Credentials already set and valid.")
        do_authorization = False
    except Exception as e:
        print("Credentials missing/invalid. Running authorization... %s" % str(e))
        do_authorization = True

    # run the authorization
    if do_authorization:
        instructions = ("To authorize mounting your Google Drive account, "
                        "visit the following URL to produce an "
                        "authorization code: \n\n%s\n\nAnd then paste the "
                        "code here:")

        # Request the authorization code from the user.
        authorize = gdrivefs.gdtool.oauth_authorize.get_auth()
        authcode = raw_input(instructions % authorize.step1_get_auth_url())

        # open a blank credentials file
        with open(credentials_file, 'w'):
            pass

        gdrivefs.gdfs.gdfuse.set_auth_cache_filepath(credentials_file)
        authorize = gdrivefs.gdtool.oauth_authorize.get_auth()

        try:
            authorize.step2_doexchange(authcode)
            print("Authorization code recorded.")
        except AuthorizationFailureError as e:
            print("Authorization Failed: %s" % str(e))
            os.remove(credentials_file)


def mount(credentials_file,mountpoint):

    command = "python %s/gdfstool.py mount %s %s" % (__gdfstool_location,credentials_file,mountpoint)
    status = os.system(command)

    return status

def unmount(credentials_file,mountpoint):
    command = "fusermount -u %s" % (mountpoint)
    status = os.system(command)

    return status





