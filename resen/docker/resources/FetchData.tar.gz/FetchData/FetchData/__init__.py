import os
import json

from external_fetchers import superdarn_fetcher, url_fetcher

_manifest_format = ['max_time','sample_count',
                    'created','bin_size',
                    'streams','samples','min_time']

_data_fetcher = {'allsky': url_fetcher,
                 'SuperDARN': superdarn_fetcher,
                 'AMIE': None,
                 'SuperMAG': None,
                }


class DataFetcher(object):

    def __init__(self, manifest_file, output_directory):

        # Basic input checking
        if not isinstance(manifest_file,str):
            print("ERROR: manifest_file must be a string!")
            return None

        if not os.path.exists(manifest_file):
            print("ERROR: Unable to open file: %s" % manifest_file)
            return None

        if not isinstance(output_directory,str):
            print("ERROR: manifest_file must be a string!")
            return None

        if not os.path.exists(output_directory):
            try:
                os.mkdir(output_directory)
                print("Created archive directory: %s" % output_directory)
            except Exception, e:
                print("ERROR: Unable access %s\nException:" % (output_directory,str(e)))
                return None

        self.output_directory = output_directory

        # Read contents of the file
        with open(manifest_file,'r') as f:
            self.manifest = json.load(f)

        # Basic check of manifest file format
        if not len(self.manifest.keys()) == len(_manifest_format):
            print("ERROR: Problem parsing manifest file.")
            return None
        for key in self.manifest.keys():
            if not key in _manifest_format:
                print("ERROR: Problem parsing manifest file:\nMissing %s" % key)
                return None

        print("Successfully loaded manifest")
        # Print information about the manifest file for the user to see
        self.print_manifest_info()

        # Initialize variables to specify what data to download for 
        # each stream type.
        # In future, this should be done using a dictionary instead
        # or the manifest should be self-descriptive...
        # self.__superdarn_radars = list()

        # Not implemented yet...
        # self.amie = None
        # self.supermag= None


    def print_manifest_info(self):
        from dateutil import parser
        from datetime import datetime

        # Get time info
        start_time   = datetime.utcfromtimestamp(self.manifest['min_time'])
        stop_time    = datetime.utcfromtimestamp(self.manifest['max_time'])
        created_date = parser.parse(self.manifest['created'])

        # data info
        # number of imagers
        num_imagers = len(self.manifest['samples'].keys())
        # data "streams"
        has_superdarn = 'SuperDARN' in self.manifest['streams'].keys()
        has_amie      = 'AMIE' in self.manifest['streams'].keys()
        has_supermag  = 'SuperMAG' in self.manifest['streams'].keys()

        print("-------------------------------------------------------")
        print("Manifest creation date:  %s" % created_date.strftime('%H:%M:%S UT on %d %b %Y'))
        print("Manifest Data Available")
        print("    Number of All-Sky Imagers: %s" % str(num_imagers))
        print("    AMIE: %s\n    SuperDARN: %s\n    SuperMAG: %s" % (has_amie,has_superdarn,has_supermag))
        print("    Start time:  %s" % start_time.strftime('%H:%M:%S UT on %d %b %Y'))
        print("      End time:  %s" % stop_time.strftime('%H:%M:%S UT on %d %b %Y'))

        # When we want to include functionality to fetch individual radar data
        # if has_superdarn:
        #     print("Use set_radars() to specify which SuperDARN radars to fetch data for.")

        print("-------------------------------------------------------")


    def download(self):
        from datetime import datetime

        # This will eventually be an argument
        # where different sources can be downloaded.
        # Either that or a function will be used to 
        # select which data sources should be downloaded
        # from the manifest.
        to_do='all'

        # some initialization
        do_allsky = False
        do_streams = {'SuperDARN': False,
                      'AIME': False,
                      'SuperMAG': False,}

        # Input checking
        if to_do == 'all':
            do_allsky = True
            do_streams['SuperDARN'] = True
            do_streams['SuperMAG'] = True
            do_streams['AMIE'] = True
        any_streams = any([do_streams[x] for x in do_streams.keys()])

        # Fetch all the allsky data ("samples")        
        if do_allsky:
            fetch_func = _data_fetcher['allsky']
            print("Fetching data for all-sky imagers...")
            for sample in self.manifest['samples']:
                num_files = len(self.manifest['samples'][sample])
                if num_files:
                    print("    Downloading %s files for: %s" % (num_files,sample))
                    save_directory = os.path.join(self.output_directory,sample)
                    if not os.path.exists(save_directory):
                        os.mkdir(save_directory)

                    for i in range(num_files):
                        url = self.manifest['samples'][sample][i]['URL']
                        fetch_func(url,save_directory)

        # Fetch all the other stuff ("streams") using their own fetchers
        if any_streams:
            # print("Fetching data using external fetchers...")
            for stream in self.manifest['streams']:
                fetch_func = _data_fetcher[stream]
                if do_streams[stream] and (not fetch_func is None):
                    start_times = self.manifest['streams'][stream][0]
                    end_times  = self.manifest['streams'][stream][0]
                    num_times = len(start_times)
                    if num_times:
                        print("    Downloading data for: %s" % stream)
                        save_directory = os.path.join(self.output_directory,stream)
                        if not os.path.exists(save_directory):
                            os.mkdir(save_directory)
                        save_directory = os.path.abspath(save_directory)
                        save_directory += '/'
                        save_directory = str(save_directory)

                        for i in range(num_times):
                            start_dt = datetime.utcfromtimestamp(start_times[0])
                            end_dt = datetime.utcfromtimestamp(end_times[0])

                            fetch_func(start_dt,end_dt,save_directory)
                elif _data_fetcher[stream] is None:
                    print("Downloader for %s is not yet implemented..." % stream)


    # Set radars is not needed for this version, since we are only fetching
    # Convection map files.
    # def set_radars(self,radar_names,reset=False):

    #     if not (isinstance(radar_names,str) or isinstance(radar_names,list)):
    #         print("ERROR: radar_names must be a str or list of strs")

    #     if isinstance(radar_names,str):
    #         radar_names = [radar_names]

    #     if reset:
    #         self.__superdarn_radars = list()

    #     for name in radar_names:
    #         if name not in self.__superdarn_radars:
    #             self.__superdarn_radars.append(name)

    #     print('Ready to fetch data for the following')
    #     print('SuperDARN radars: %s' % str(self.__superdarn_radars))

