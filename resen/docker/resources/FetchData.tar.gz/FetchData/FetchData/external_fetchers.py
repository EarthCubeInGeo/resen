# methods for fetching data

def url_fetcher(url, save_directory):
    import os
    import urllib2
    from contextlib import closing
    # takes in a dictionary of format:
    # dict = {'URL':'some url','time':utctimestamp in unix epoch seconds}

    # first check the file at the link and look/compare with archived.

    filename = os.path.basename(url)

    output_filename = os.path.join(save_directory,filename)

    with closing(urllib2.urlopen(url)) as d:
        url_size = int(d.info()['Content-Length'])

        download = True
        if os.path.exists(output_filename):
            output_size = os.stat(output_filename).st_size
            if output_size == url_size:
                print("    Already have file: %s" % filename)
                download = False

        if download:
            with open(output_filename,'w') as f:
                f.write(d.read())

    if download:
        output_size = os.stat(output_filename).st_size
        if not output_size == url_size:
            print("Problem downloading file from: %s" % url)
            try:
                os.remove(output_filename)
            except Exception:
                pass
        else:
            print("    Successfully downloaded: %s" % filename)


def superdarn_fetcher(stime,etime,save_directory):
    import davitpy
    from davitpy.pydarn.sdio import fetchUtils as futils

    # only get the grid data, not map?

    # use fetchUtils to get the map files for both northern and southern hemispheres.

   # davitpy.rcParams['verbosity'] = 'silent'


    remote_dirfmt = davitpy.rcParams['DAVIT_SD_REMOTE_DIRFORMAT']
    remote_fnamefmt = davitpy.rcParams['DAVIT_SD_REMOTE_FNAMEFMT'].split(',')
    remote_site = davitpy.rcParams['DB']
    port = davitpy.rcParams['DB_PORT']
    username = davitpy.rcParams['DBREADUSER']
    password = davitpy.rcParams['DBREADPASS']


    hemispheres = ['north','south']
    filetypes = ['mapex','grdex']

    #What files are we grabbing by default?

    print("    Downloading mapex and grdex files...")

    for ftype in filetypes:
        for hemi in hemispheres:

            remote_dict = {'ftype':ftype, 'hemi':hemi}

            

            temp = futils.fetch_remote_files(stime,etime,'sftp',remote_site,
                                             remote_dirfmt,remote_dict,save_directory,
                                             remote_fnamefmt,username=username,
                                             password=password,port=port,
                                             check_cache=True)



